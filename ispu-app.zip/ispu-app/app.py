"""Aplikasi web prediksi kategori ISPU H+1 DKI Jakarta (Streamlit)."""
from __future__ import annotations

from datetime import timedelta

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import ispu
from ispu import KELAS, NAMA_POLUTAN, POLUTAN

st.set_page_config(page_title="Prediksi ISPU H+1 Jakarta", page_icon="🌿", layout="wide")

WARNA = {"BAIK": "#5f8d5f", "SEDANG": "#f2b630", "TIDAK SEHAT": "#e8693a"}
HIJAU = "#1f4d2b"
TEKS_GELAP = {"BAIK": "#fff", "SEDANG": "#3b2f00", "TIDAK SEHAT": "#fff"}
SARAN = {
    "BAIK": "Kualitas udara baik. Aktivitas luar ruangan aman dilakukan.",
    "SEDANG": "Kualitas udara sedang. Kelompok sensitif (anak, lansia, penderita asma) sebaiknya mengurangi aktivitas berat di luar ruangan.",
    "TIDAK SEHAT": "Kualitas udara tidak sehat. Kurangi aktivitas luar ruangan, gunakan masker, dan perhatikan kelompok rentan.",
}

st.markdown(
    f"""
<style>
.stApp {{ background: linear-gradient(160deg,#eef2e6 0%,#e3ebd9 55%,#dbe6d0 100%); }}
[data-testid="stSidebar"] {{ background:#f6f8f0; border-right:1px solid #d3dcc6; }}
h1,h2,h3 {{ color:{HIJAU}; letter-spacing:-0.01em; }}
.kartu {{ background:#fbfcf7; border:1px solid #d7e0c9; border-radius:18px; padding:18px 22px; box-shadow:0 2px 10px rgba(31,77,43,.07); }}
.hasil {{ border-radius:20px; padding:26px 28px; }}
.hasil .label {{ font-size:.85rem; letter-spacing:.12em; text-transform:uppercase; opacity:.85; }}
.hasil .nilai {{ font-size:2.6rem; font-weight:800; line-height:1.1; margin:.2rem 0 .4rem; }}
.pil {{ display:inline-block; padding:3px 12px; border-radius:999px; font-weight:700; font-size:.85rem; }}
.kecil {{ color:#5a6b5a; font-size:.88rem; }}
div[data-testid="stMetric"] {{ background:#fbfcf7; border:1px solid #d7e0c9; border-radius:14px; padding:10px 14px; }}
</style>
""",
    unsafe_allow_html=True,
)


_BLN = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]


def tgl(d) -> str:
    d = pd.Timestamp(d)
    return f"{d.day} {_BLN[d.month - 1]} {d.year}"


def pil(k: str) -> str:
    return f'<span class="pil" style="background:{WARNA[k]};color:{TEKS_GELAP[k]}">{k}</span>'


@st.cache_data
def data():
    return ispu.load_data()


@st.cache_resource
def model(nama):
    return ispu.muat_model(nama)


df = data()
STASIUN = sorted(df["stasiun"].unique())
MEDIAN = {p: float(df[p].median()) for p in POLUTAN}

# ------------------------------------------------------------------ sidebar
st.sidebar.markdown(f"<h2 style='margin-bottom:0'>🌿 ISPU H+1</h2><div class='kecil'>Prediksi kualitas udara besok · DKI Jakarta</div>", unsafe_allow_html=True)
halaman = st.sidebar.radio("Menu", ["Prediksi", "Eksplorasi Data", "Evaluasi Model", "Tentang Proyek"], label_visibility="collapsed")
st.sidebar.markdown("---")
st.sidebar.caption("Mata Kuliah Pembelajaran Mesin · Kelompok 6 – Kelas A · Sekolah Vokasi IPB")


# ================================================================== PREDIKSI
def halaman_prediksi():
    st.title("Prediksi Kategori ISPU Besok")
    st.markdown("Pilih stasiun dan tanggal, lalu model memperkirakan kategori ISPU **hari berikutnya (H+1)** beserta peluang tiap kategori.")

    tersedia = ispu.model_tersedia()
    if not tersedia:
        st.error("Belum ada file model di folder `models/`. Letakkan `model_random_forest.joblib` di sana.")
        return

    c1, c2, c3 = st.columns([1.2, 1.2, 1])
    nama_model = c1.selectbox("Model", list(tersedia), help="Model yang tersedia di folder models/")
    stasiun = c2.selectbox("Stasiun", STASIUN)
    g = df[df["stasiun"] == stasiun]
    tmin, tmax = g["tanggal"].min().date(), g["tanggal"].max().date()
    tanggal = c3.date_input("Tanggal hari ini (H)", value=tmax, min_value=tmin, max_value=tmax + timedelta(days=3650))
    mode = st.radio("Sumber data", ["Data historis", "Input manual"], horizontal=True,
                    help="Historis: nilai diambil otomatis dari data bersih. Manual: ubah nilai 7 hari terakhir sendiri.")

    bundle, is_demo = model(nama_model)
    if bundle is None:
        st.error(f"File model {ispu.MODEL_FILES[nama_model]} belum ada di folder models/.")
        return
    if is_demo:
        st.warning("**Model demo.** File `model_random_forest.joblib` yang asli belum dipasang, jadi hasil di bawah berasal dari model pengganti dan bukan hasil model proyek. Salin file asli ke folder `models/` untuk memakai model proyek.", icon="⚠️")

    t = pd.Timestamp(tanggal)
    riw = g[g["tanggal"] <= t]
    aktual_h = g[g["tanggal"] == t]

    if mode == "Data historis":
        if aktual_h.empty:
            st.info("Tidak ada pengukuran pada tanggal ini untuk stasiun tersebut. Pilih tanggal lain, atau pakai **Input manual**.")
            return
        hist = riw[["tanggal"] + POLUTAN]
        kat_hari_ini = aktual_h["kategori"].iloc[0]
    else:
        st.markdown("**Nilai sub-indeks 7 hari terakhir** (baris paling bawah = hari ini). Ubah langsung di tabel.")
        hari = pd.date_range(t - timedelta(days=6), t)
        awal = g.set_index("tanggal").reindex(hari)[POLUTAN]
        awal = awal.fillna(pd.Series(MEDIAN)).round(0)
        awal.index = [tgl(d) for d in hari]
        edit = st.data_editor(awal, width="stretch", num_rows="fixed",
                              column_config={p: st.column_config.NumberColumn(NAMA_POLUTAN[p], min_value=0, max_value=500, step=1) for p in POLUTAN})
        hist = edit.copy()
        hist.insert(0, "tanggal", hari)
        kat_hari_ini = ispu.kategori_dari_nilai(float(edit.iloc[-1].max()))

    try:
        X, diisi = ispu.bangun_fitur(hist, t, stasiun, bundle["fitur"], STASIUN, MEDIAN)
    except ispu.FiturTidakDikenal as e:
        st.error("Nama fitur di file model belum dikenali oleh aplikasi:\n\n`" + "`, `".join(e.names[:12]) + "`\n\nJalankan `python cek_model.py` untuk detailnya.")
        return
    proba = ispu.prediksi_proba(bundle, X)
    pred = max(proba, key=proba.get)

    st.markdown("")
    kiri, kanan = st.columns([1, 1.15], gap="large")
    with kiri:
        st.markdown(
            f"""<div class="hasil" style="background:{WARNA[pred]};color:{TEKS_GELAP[pred]}">
<div class="label">Prediksi {tgl(t + timedelta(days=1))}</div>
<div class="nilai">{pred}</div>
<div>Keyakinan model {proba[pred]*100:.0f}%</div></div>""",
            unsafe_allow_html=True,
        )
        st.markdown("")
        st.markdown(f'<div class="kartu"><b>Hari ini ({tgl(t)}):</b> {pil(kat_hari_ini)}{"" if mode == "Data historis" else " <span class=kecil>(perkiraan dari 5 polutan)</span>"}<br><span class="kecil">{SARAN[pred]}</span></div>', unsafe_allow_html=True)
        if mode == "Data historis":
            besok = g[g["tanggal"] == t + timedelta(days=1)]
            if not besok.empty:
                nyata = besok["kategori"].iloc[0]
                ok = "✅ tepat" if nyata == pred else "❌ meleset"
                st.markdown(f'<div class="kartu" style="margin-top:10px"><b>Kenyataan H+1:</b> {pil(nyata)} &nbsp; {ok}</div>', unsafe_allow_html=True)
        if diisi:
            st.caption(f"ℹ️ {diisi} nilai riwayat yang kosong diisi otomatis (nilai terdekat/median stasiun).")
    with kanan:
        fig = go.Figure(go.Bar(
            x=[proba[k] * 100 for k in KELAS], y=KELAS, orientation="h",
            marker_color=[WARNA[k] for k in KELAS],
            text=[f"{proba[k]*100:.1f}%" for k in KELAS], textposition="outside",
        ))
        fig.update_layout(title="Peluang tiap kategori", height=250, margin=dict(l=0, r=30, t=40, b=0),
                          xaxis=dict(range=[0, 108], ticksuffix="%"), yaxis=dict(autorange="reversed"),
                          paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig, width="stretch")

        h7 = hist.tail(7).copy()
        h7["tanggal"] = pd.to_datetime(h7["tanggal"])
        fig2 = go.Figure()
        for p in POLUTAN:
            fig2.add_trace(go.Scatter(x=h7["tanggal"], y=h7[p], name=NAMA_POLUTAN[p], mode="lines+markers"))
        fig2.update_layout(title="Riwayat 7 hari terakhir (sub-indeks ISPU)", height=300, margin=dict(l=0, r=0, t=40, b=0),
                           legend=dict(orientation="h", y=-0.2), colorway=["#1f4d2b", "#7aa37a", "#f2b630", "#e8693a", "#6b5b3e"], paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig2, width="stretch")

    with st.expander("Fitur yang dimasukkan ke model"):
        st.dataframe(X.T.rename(columns={0: "nilai"}), width="stretch", height=300)
    st.caption("Catatan: akurasi model terbatas (lihat halaman *Evaluasi Model*). Hasil ini adalah alat bantu pembelajaran, bukan peringatan resmi kualitas udara.")


# ============================================================ EKSPLORASI DATA
def halaman_eksplorasi():
    st.title("Eksplorasi Data")
    a, b, c, d = st.columns(4)
    a.metric("Jumlah baris", f"{len(df):,}".replace(",", "."))
    b.metric("Stasiun", df["stasiun"].nunique())
    c.metric("Periode", f"{df['tanggal'].min().year}–{df['tanggal'].max().year}")
    d.metric("Polutan", "5 sub-indeks")

    l, r = st.columns([1, 1.4], gap="large")
    with l:
        dist = df["kategori"].value_counts().reindex(KELAS)
        fig = go.Figure(go.Pie(labels=dist.index, values=dist.values, hole=0.55, marker_colors=[WARNA[k] for k in dist.index], sort=False))
        fig.update_layout(title="Komposisi kategori", height=330, margin=dict(l=0, r=0, t=40, b=0), paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig, width="stretch")
        st.caption("Kategori SEDANG mendominasi (±68%), sehingga akurasi saja bisa menyesatkan.")
    with r:
        pilih = st.selectbox("Stasiun", ["Semua stasiun"] + STASIUN)
        pol = st.selectbox("Polutan", POLUTAN, format_func=lambda p: NAMA_POLUTAN[p])
        x = df if pilih == "Semua stasiun" else df[df["stasiun"] == pilih]
        m = x.set_index("tanggal")[pol].resample("MS").mean().reset_index()
        fig = go.Figure(go.Scatter(x=m["tanggal"], y=m[pol], line=dict(color=HIJAU)))
        fig.update_layout(title=f"Rata-rata bulanan {NAMA_POLUTAN[pol]}", height=300, margin=dict(l=0, r=0, t=40, b=0),
                          paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig, width="stretch")

    st.subheader("Kategori per stasiun")
    tb = pd.crosstab(df["stasiun"], df["kategori"])[KELAS]
    fig = go.Figure([go.Bar(name=k, x=tb.index, y=tb[k], marker_color=WARNA[k]) for k in KELAS])
    fig.update_layout(barmode="stack", height=320, margin=dict(l=0, r=0, t=10, b=0), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
    st.plotly_chart(fig, width="stretch")

    st.subheader("Ringkasan pembersihan data")
    rg = pd.read_excel(ispu.BASE / "data" / "data_bersih.xlsx", sheet_name="ringkasan")
    rg.columns = ["Langkah", "Keterangan", "Jumlah baris"]
    st.dataframe(rg, width="stretch", hide_index=True)


# ============================================================= EVALUASI MODEL
LAPORAN = {
    "Logistic Regression": {"BAIK": (0.18, 0.94, 0.30, 564), "SEDANG": (0.80, 0.44, 0.56, 3866), "TIDAK SEHAT": (0.00, 0.00, 0.00, 600)},
    "Decision Tree": {"BAIK": (0.18, 0.97, 0.30, 564), "SEDANG": (0.82, 0.41, 0.55, 3866), "TIDAK SEHAT": (0.31, 0.01, 0.01, 600)},
    "Random Forest": {"BAIK": (0.25, 0.84, 0.38, 564), "SEDANG": (0.80, 0.56, 0.66, 3866), "TIDAK SEHAT": (0.17, 0.11, 0.13, 600)},
}
OVERFIT = pd.DataFrame({"F1 macro latih": [0.6062, 0.6121, 0.8740], "F1 macro uji": [0.2896, 0.2863, 0.3903]},
                       index=["Logistic Regression", "Decision Tree", "Random Forest"])
OVERFIT["Selisih"] = (OVERFIT["F1 macro latih"] - OVERFIT["F1 macro uji"]).round(4)


def halaman_evaluasi():
    st.title("Evaluasi Model")
    st.markdown("Data latih: 2010–Apr 2021 (17.464 baris) · Data uji: Apr 2021–Feb 2025 (5.030 baris) · Validasi: `TimeSeriesSplit` 5 lipatan, penilaian F1 macro.")
    t = pd.read_csv(ispu.BASE / "data" / "perbandingan_model.csv", index_col=0)

    metrik = st.multiselect("Metrik pada grafik", ["Accuracy", "F1 (macro)", "Recall TIDAK SEHAT"], default=["F1 (macro)", "Accuracy"])
    warna = {"Accuracy": "#9db99d", "F1 (macro)": HIJAU, "Recall TIDAK SEHAT": "#e8693a"}
    fig = go.Figure([go.Bar(name=m, x=t.index, y=t[m], marker_color=warna[m], text=t[m].round(3), textposition="outside") for m in metrik])
    fig.update_layout(barmode="group", height=360, margin=dict(l=0, r=0, t=10, b=0), yaxis=dict(range=[0, 1]),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", legend=dict(orientation="h", y=1.12))
    st.plotly_chart(fig, width="stretch")
    st.dataframe(t.round(4).astype(object).where(t.notna(), "–"), width="stretch")

    best = t.loc[["Baseline persistensi", "Random Forest"], "F1 (macro)"]
    st.info(
        f"**Temuan.** Random Forest memiliki F1 macro validasi tertinggi (0,6032), sehingga dipilih sebagai model utama. "
        f"Pada data uji, F1 macro-nya {best['Random Forest']:.3f}, sedangkan baseline persistensi (besok dianggap sama dengan hari ini) mencapai {best['Baseline persistensi']:.3f}. "
        "Selisih besar antara skor latih dan uji (tabel di bawah) menunjukkan model belum menggeneralisasi dengan baik ke periode 2021–2025.",
        icon="📌",
    )

    l, r = st.columns(2, gap="large")
    with l:
        st.subheader("Cek overfitting")
        st.dataframe(OVERFIT, width="stretch")
    with r:
        st.subheader("Laporan per kelas")
        nm = st.selectbox("Model", list(LAPORAN), index=2)
        rep = pd.DataFrame(LAPORAN[nm], index=["Precision", "Recall", "F1", "Support"]).T
        rep["Support"] = rep["Support"].astype(int)
        st.dataframe(rep, width="stretch")

    st.subheader("Gambar dari notebook")
    for f, cap in [("confusion_matrix_3_model.png", "Confusion matrix tiga model"), ("fitur_penting_pohon.png", "Fitur terpenting (Decision Tree dan Random Forest)")]:
        p = ispu.BASE / "assets" / f
        if p.exists():
            st.image(str(p), caption=cap, width="stretch")
        else:
            st.caption(f"Letakkan `{f}` di folder `assets/` untuk menampilkan: {cap}.")


# ================================================================== TENTANG
def halaman_tentang():
    st.title("Tentang Proyek")
    st.markdown(
        """
**Prediksi Kategori ISPU Harian H+1 di DKI Jakarta Menggunakan Perbandingan Algoritma Machine Learning Berbasis Fitur Historis Polutan**

Kajian terdahulu umumnya mengklasifikasikan kondisi udara pada hari yang sama. Proyek ini memprediksi kategori **hari berikutnya** agar bisa dipakai sebagai peringatan dini.
"""
    )
    k1, k2, k3, k4 = st.columns(4)
    for col, (judul, isi) in zip([k1, k2, k3, k4], [
        ("1 · Hari ini", "Sub-indeks PM10, SO₂, CO, O₃, NO₂ per stasiun"),
        ("2 · Pengolahan", "Riwayat 7 hari, rata-rata 3 dan 7 hari, bulan, hari dalam minggu"),
        ("3 · Model ML", "Logistic Regression, Random Forest, Decision Tree"),
        ("4 · Hasil H+1", "Kategori ISPU besok dan peluang tiap kelas"),
    ]):
        col.markdown(f'<div class="kartu"><b>{judul}</b><br><span class="kecil">{isi}</span></div>', unsafe_allow_html=True)
    st.markdown("")
    st.markdown(
        """
**Data.** Air Quality Index in Jakarta (Kaggle, salinan Satu Data Jakarta): lima stasiun SPKU, 2010–2025. Kelas *sangat tidak sehat* dan *berbahaya* digabung ke *tidak sehat*, sehingga target menjadi tiga kelas: BAIK, SEDANG, TIDAK SEHAT. Baris yang labelnya bertentangan dengan nilai maksimum, serta kolom `max` dan `critical`, dibuang untuk mencegah kebocoran target.

**Evaluasi.** Dua baseline (persistensi dan kelas mayoritas), F1 macro sebagai metrik utama, pembagian latih/uji berdasarkan waktu.

**Tim.** Yuwandri Alfarizi (J0404241010) · Adnan Muhammad G. K. (J0404241098) · Nayla Januarisa Prihadi (J0404241149) — Kelompok 6, Kelas A.
"""
    )


{"Prediksi": halaman_prediksi, "Eksplorasi Data": halaman_eksplorasi, "Evaluasi Model": halaman_evaluasi, "Tentang Proyek": halaman_tentang}[halaman]()
